from django.contrib import admin
from .models import Especiaria, Quadro, Artefato, Livro

# Register your models here.
admin.site.register(Especiaria)
admin.site.register(Quadro)
admin.site.register(Artefato)
admin.site.register(Livro)
