from django.views.generic import TemplateView
from django.shortcuts import redirect
from django.contrib.auth import logout
from django.views.generic.edit import CreateView
from .forms import UsuarioForm
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from braces.views import GroupRequiredMixin
from django.contrib.auth.models import Group
from django.shortcuts import get_object_or_404

# Create your views here.
class EncerrarSessaoView(TemplateView):

    def user_logout(request):
        if request.method == 'POST':
            if request.user.is_authenticated:
                logout(request)
        return redirect('login')

class UsuarioCreate(GroupRequiredMixin, LoginRequiredMixin, CreateView):
    group_required = u"Gerenciador"
    template_name = "produtos/form.html"
    form_class = UsuarioForm
    success_url = reverse_lazy('inicio')

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['titulo'] = "Registro de novo usuário"
        context['botao'] = "Cadastrar"
        return context

    def form_valid(self, form):
        grupo = get_object_or_404(Group, name="Cliente")
        url = super().form_valid(form)
        self.object.set_password(form.cleaned_data["senha"])
        self.object.save()
        grupo_escolhido = form.cleaned_data["grupo"]
        self.object.groups.add(grupo_escolhido)
        return url


